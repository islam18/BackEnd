package com.Carthago.conformite.clients.repositories;
import com.Carthago.conformite.clients.entities.contact;
import org.springframework.data.jpa.repository.JpaRepository;
public interface contactRepository extends JpaRepository<contact,Long> {
}