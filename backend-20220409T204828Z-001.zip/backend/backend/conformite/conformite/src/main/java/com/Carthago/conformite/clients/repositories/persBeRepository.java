package com.Carthago.conformite.clients.repositories;


import com.Carthago.conformite.clients.entities.persBe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface persBeRepository extends JpaRepository<persBe,Long> {
}
