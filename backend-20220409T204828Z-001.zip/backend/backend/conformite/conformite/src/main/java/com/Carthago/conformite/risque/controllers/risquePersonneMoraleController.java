package com.Carthago.conformite.risque.controllers;

import com.Carthago.conformite.clients.entities.personneMorale;
import com.Carthago.conformite.risque.serviceImp.RisquePersonneMorale;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
@RestController
@RequestMapping(value="/Risque",method= {RequestMethod.GET})
public class risquePersonneMoraleController {
    @Autowired
    RisquePersonneMorale RService ;

    /*@GetMapping("/Get/{id}")
    public ArrayList<Long> risqueGeographique(@PathVariable long id)
    {
        return RService.risqueGeographique(id);
    }*/
}
