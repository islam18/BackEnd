package com.Carthago.conformite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConformiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
