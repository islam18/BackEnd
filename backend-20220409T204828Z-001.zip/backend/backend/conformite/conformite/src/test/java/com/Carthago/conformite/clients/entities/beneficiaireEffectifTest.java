package com.Carthago.conformite.clients.entities;

import com.Carthago.conformite.clients.repositories.beneficiareEffectifRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class beneficiaireEffectifTest {

    @Autowired
    private beneficiareEffectifRepository repository;

    @Test
    void testCreateBeneficiaire()
    {beneficiaireEffectif b = new beneficiaireEffectif((long) 12501258,255858);
     repository.save(b);

    }

    /*@Test
    void testGetPourcentage() {

            beneficiaireEffectif b = new beneficiaireEffectif((long) 12501258,255858);
            assertEquals(255858,b.getPourcentage());
    }*/
}
