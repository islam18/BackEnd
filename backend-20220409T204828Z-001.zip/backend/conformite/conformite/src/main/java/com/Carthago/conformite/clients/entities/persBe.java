package com.Carthago.conformite.clients.entities;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Setter
@Getter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class persBe {
    //declaration des variables
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long code;
    private Long codeClient;
    private  Long codeBe;

}
