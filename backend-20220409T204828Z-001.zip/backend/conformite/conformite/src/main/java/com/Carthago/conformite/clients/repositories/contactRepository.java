package com.Carthago.conformite.clients.repositories;

public interface contactRepository {
}
