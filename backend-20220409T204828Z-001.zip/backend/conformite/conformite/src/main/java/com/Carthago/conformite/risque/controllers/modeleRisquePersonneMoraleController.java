package com.Carthago.conformite.risque.controllers;

public class modeleRisquePersonneMoraleController {
}
